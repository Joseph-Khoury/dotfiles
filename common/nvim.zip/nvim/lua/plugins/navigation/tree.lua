return {
    'nvim-tree/nvim-tree.lua',
    dependencies = {
        'nvim-tree/nvim-web-devicons',
    } , -- optional icons
    config = function()
        local function my_on_attach (bufnr)
            local api = require "nvim-tree.api"

            local function opts (desc)
                return {
                    desc = "nvim-tree: " .. desc,
                    buffer = bufnr, noremap = true,
                    silent = true,
                    nowait = true,
                }
            end


            -- -- default mappings
            -- api.config.mappings.default_on_attach(bufnr)

            -- custom mappings
            -- vim.keymap.set('n', '<C-t>', api.tree.change_root_to_parent, opts('Up'))
            vim.keymap.set('n', '?', api.tree.toggle_help, opts('Help'))

            -- auto-open file after creation
            api.events.subscribe(api.events.Event.FileCreated, function(file)
                vim.cmd("edit " .. file.fname)
            end)
        end
        require("nvim-tree").setup({
            on_attach = my_on_attach,
            view = {
                width = 30,
                side = "left",
            },
            filters = {
                dotfiles = false,
            },
            actions = {
                open_file = {
                    quit_on_open = true,
                },
            },
        })
    end
}

